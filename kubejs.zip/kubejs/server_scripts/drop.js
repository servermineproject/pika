onEvent('block.loot_tables', event => {
    event.addSimpleBlock('kubejs:carminita_ore', 'kubejs:raw_carminita')
  })