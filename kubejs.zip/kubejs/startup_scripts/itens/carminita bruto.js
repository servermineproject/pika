onEvent('item.registry', event => {
	event.create('raw_carminita').displayName('Minério bruto de Carminita')
})
