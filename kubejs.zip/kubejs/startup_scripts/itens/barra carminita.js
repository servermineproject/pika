onEvent('item.registry', event => {
	event.create('carminita_bar').displayName('Barra de Carminita')
})
