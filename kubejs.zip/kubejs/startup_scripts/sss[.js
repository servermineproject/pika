onEvent('item.registry.armor_tiers', event => {
    event.add('carminita', tier => {
      tier.durabilityMultiplier = 100
      tier.slotProtections = [4, 7, 14, 4]
      tier.enchantmentValue = 25
      tier.equipSound = 'minecraft:item.armor.equip_leather'
      tier.repairIngredient = 'minecraft:leather'
      tier.toughness = 10.0
      tier.knockbackResistance = 3.0
      
    })
  }) 
  
  onEvent('item.registry', event => {
      event.create('carminita_helmet','helmet').tier('carminita').displayName('Elmo de Carminita')
      event.create('carminita_chestplate', 'chestplate').tier('carminita').displayName('Peitoral de Carminita')
      event.create('carminita_leggings', 'leggings').tier('carminita').displayName('Calças de Carminita')
      event.create('carminita_boots', 'boots').tier('carminita').displayName('Botas de Carminita')
  })
  