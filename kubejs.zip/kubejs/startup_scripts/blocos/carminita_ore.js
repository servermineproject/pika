onEvent('block.registry', event => {
	 event.create('carminita_ore').material('stone').hardness(3.0).displayName('Minério de carminita').tagBlock('minecraft:mineable/pickaxe').tagBlock('minecraft:needs_diamond_tool')
})